# BHANU TRACKER — GPS Tracking Website (Free to Host)

A professional, static one‑page website you can host **free** on GitHub Pages or Netlify.
All content is editable. Replace placeholder logo/images in `assets/img`.

## Quick Start
1. **Edit text** in `index.html` and data in `assets/data/*.json`.
2. **Replace logo**: put `logo.png` (transparent background) in `assets/img` and update `index.html` img src if needed.
3. **Contact Form** uses Formspree (free). Update the `action` URL in the form to your Formspree endpoint.

## Deploy Free — Option A: Netlify
- Create account → New site from Git → Connect your repo.
- Or drag & drop this folder on https://app.netlify.com/drop
- Your site will be live at `https://YOURNAME.netlify.app`

## Deploy Free — Option B: GitHub Pages
- Create repo, upload files, then Settings → Pages → Deploy from branch (root).
- Live at `https://USERNAME.github.io`

## Customize
- **Products**: `assets/data/products.json`
- **Pricing**: `assets/data/pricing.json`
- **Colors/Theme**: `assets/css/styles.css` (CSS variables at the top)
- **WhatsApp Button**: update your number in `index.html`

© 2025-08-27 BHANU TRACKER
