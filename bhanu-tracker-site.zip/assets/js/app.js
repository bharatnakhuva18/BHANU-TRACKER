// Mobile nav toggle
const hamburger = document.getElementById('hamburger');
if (hamburger) {
  hamburger.addEventListener('click', () => {
    const nav = document.querySelector('.nav');
    if (nav) nav.style.display = nav.style.display === 'block' ? 'none' : 'block';
  });
}

// Load products & pricing from data files
async function loadJSON(url) {
  const res = await fetch(url);
  return res.json();
}

async function renderProducts() {
  try {
    const data = await loadJSON('assets/data/products.json');
    const grid = document.getElementById('productGrid');
    grid.innerHTML = data.products.map(p => `
      <div class="card">
        <h3>${p.name}</h3>
        <p>${p.desc}</p>
        <p><strong>Sensors:</strong> ${p.sensors.join(', ')}</p>
      </div>
    `).join('');
  } catch (e) { console.error('Products load error', e); }
}

async function renderPricing() {
  try {
    const data = await loadJSON('assets/data/pricing.json');
    const grid = document.getElementById('pricingGrid');
    grid.innerHTML = data.plans.map(pl => `
      <div class="card">
        <h3>${pl.title}</h3>
        <p class="muted">${pl.subtitle}</p>
        <h2>${pl.price}</h2>
        <ul>
          ${pl.features.map(f => `<li>✔ ${f}</li>`).join('')}
        </ul>
        <a class="btn primary" href="#contact">Choose Plan</a>
      </div>
    `).join('');
  } catch (e) { console.error('Pricing load error', e); }
}

renderProducts();
renderPricing();

// Simple form success message (works with Formspree success redirect by default)
const form = document.getElementById('contactForm');
if (form) {
  form.addEventListener('submit', () => {
    // Allow native submit to Formspree; optional user feedback can be added here.
  });
}
